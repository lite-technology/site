import styled from "styled-components";

export const Container = styled.div`

padding:  ${({theme}) => theme.sizes.containerPadding};
  background-color: ${({theme}) => theme.colors.background};
  width: 100%;
  height: 200vh;
padding-top: 10vh;


`

export const SectionContainer = styled.section`
  width: 100%;
  height: 80vh;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;

  img{
    height: 20%;
    width: auto;
    z-index: 10;
  }

  span{
    border-radius: 50%;
    width: 0;
    height: 0;
    position: absolute;
    display: flex;
animation: opacity 3s infinite ease-in-out;
    background-color: ${({theme}) => theme.colors.primary};
    &:nth-child(2){
      animation-delay:1s;
    }
    &:nth-child(3){
      animation-delay: 2s;
    }

  }

  @keyframes opacity{
    0%{
      opacity: 0.01;
      width: 0;
      height: 0;
    }
    
    70% {
      opacity: 0.05;
      width: 150vh;
      height: 150vh;
    }

    100% {
      opacity: 0;
      width: 145vh;
      height: 145vh;
    }
    
  }
`