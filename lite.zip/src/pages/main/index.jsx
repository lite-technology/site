import React from 'react';

import logo from '../../assets/imgs/logo.png'
import Navbar from '../../components/navbar';
import Footer from '../../components/footer';

import { Container, SectionContainer} from './styles';
const Main = () => {

    return (
        <>
            <Navbar />
            <Container>
               <SectionContainer>
                 <img src={logo} alt="Lite technology" />
                 <span></span>
                 <span></span>
                 <span></span>
               
               </SectionContainer>
            </Container>
        </>
    )
}

export default Main